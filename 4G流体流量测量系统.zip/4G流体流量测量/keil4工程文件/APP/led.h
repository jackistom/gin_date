#include<reg52.h>

sbit run=P2^0;
sbit warning=P2^1;
sbit link=P2^2;
