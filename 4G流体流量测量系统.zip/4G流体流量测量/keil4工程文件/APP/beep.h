#include<reg52.h>

sbit beep=P2^7;

void voice(int x);