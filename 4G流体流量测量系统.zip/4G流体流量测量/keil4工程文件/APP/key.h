#include<reg52.h>

sbit menu=P3^3;
sbit up=P3^4;
sbit cut=P3^5;
sbit down=P3^6;
sbit ok=P2^5;
sbit add=P2^3;
