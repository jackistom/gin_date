#include<delay.h>

void delay500ms(void)   //��� 0us
{
    unsigned char a,b,c;
    for(c=205;c>0;c--)
        for(b=116;b>0;b--)
            for(a=9;a>0;a--);
}

void delay100ms(void)   //��� 0us
{
    unsigned char a,b,c;
  
  for(c=7;c>0;c--)
        for(b=74;b>0;b--)
            for(a=95;a>0;a--);
}