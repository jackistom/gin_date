#include<reg52.h>
#include<lcd.h>
#include<led.h>
#include<beep.h>
#include<delay.h>
#include<key.h>
#include<menu.h>
#include"i2c.h"
sbit water=P3^2;//��������

//���㹫ʽF=0.45Q (FƵ�� Q����L/min)

char display1[16]={"F:           . L"};//����
char display2[16]={"V:      .  L/min"};//����
char Alarm_upper=10;//����������
char Alarm_lower=0;
float speed;
float flow;
int	h,Hz;//Ƶ�ʼ������
int n;//runָʾ�Ƽ�ʱ����
int save_in;
int warn=0;//��������

void Time_UsartInit()//��ʱ���ʹ��ڳ�ʼ��
{
	SCON=0X40;		
	TMOD|=0X21;		
	PCON=0X80;			
	TH1 = 0xFA;
    TL1 = TH1;
	ES=1;						
	TR1=1;//����9600
	IP=0X10;					

    TH0 = 0x0FF;
    TL0 = 0x9C;
    ET0 = 1;
	TR0 = 1;//��ʱ��100us
	
	IT0=1;
	EX0=1;//�ⲿ�ж�0
		
	EA=1;	
}

void SendOneByte(unsigned char c)//���ڷ���һ���ֽ�
{
    SBUF = c;
    while(!TI);
    TI = 0;
}

void AllInit()//�ܳ�ʼ��
{	
	LcdInit();
	check();
	Time_UsartInit();	
}

void Interface()//����ʾ����
{
	Lcd1602_Display(1,display1);
	Lcd1602_Display(2,display2);
}

int main()
{
	int speed_int,flow_int,save,s;
	char send[]={"   .  L/min"};
	AllInit();		
	while(1)
	{
		Interface();
		speed_int=speed*100;
		display2[5]=speed_int/10000+48;
		display2[6]=speed_int/1000%10+48;
		display2[7]=speed_int/100%10+48;
		display2[9]=speed_int/10%10+48;
		display2[10]=speed_int%10+48;

		flow_int=flow*10;
		display1[6]=flow_int/10000000%10+48;
		display1[7]=flow_int/1000000%10+48;
		display1[8]=flow_int/100000%10+48;
		display1[9]=flow_int/10000%10+48;
		display1[10]=flow_int/1000%10+48;
		display1[11]=flow_int/100%10+48;
		display1[12]=flow_int/10%10+48;
		display1[14]=flow_int%10+48;

		if(menu==0)
		{
			delay100ms();
			if(menu==0)
			{
				ET0=0;
				TR0=0;
				EA=0;
				Option_menu();
				EA=1;
				ET0=1;
				TR0=1;
			}
		}
		save++;
		if(save==5)
		{
			if(warn!=1)
				voice(35);//��ֹ�洢��ʾ�ͱ���һ������
			save=0;
			save_in=speed/3;
		    At24c02Write(0,save_in);
			send[0]=speed_int/10000+48;
			send[1]=speed_int/1000%10+48;
			send[2]=speed_int/100%10+48;
			send[4]=speed_int/10%10+48;
			send[5]=speed_int%10+48;
			send[13]='_';
			send[14]='_';
			send[15]='_';
			send[16]='_';
			send[17]='_';
			send[18]=flow_int/10000000%10+48;
			send[19]=flow_int/1000000%10+48;
			send[20]=flow_int/100000%10+48;
			send[21]=flow_int/10000%10+48;
			send[22]=flow_int/1000%10+48;
			send[23]=flow_int/100%10+48;
			send[24]=flow_int/10%10+48;
			send[25]='.';
			send[26]=flow_int%10+48;
			send[27]='L';
		 	ET0 = 0;
			TR0 = 0;
			IT0=0;
			EX0=0;
			EA=0;
			for(s=0;s<28;s++)
				SendOneByte(send[s]);
			if(warn==1)
			{
				SendOneByte('_');
				SendOneByte('_');
				SendOneByte('_');
				SendOneByte('!');
				SendOneByte('!');
			}
			EA=1;
			ET0 = 1;
			TR0 = 1;
			IT0=1;
			EX0=1;
		}
		if(warn==1)//����
		{
			
			voice(25);
			warning=~warning;
		}
		else
			warning=1;
	}
}


int er;//���ж����
void Timer0Interrupt(void) interrupt 1
{
    TH0 = 0x0FF;
    TL0 = 0x9C;
    //add your code here!
	n++;
	if(n==5000)
	{
		n=0;
		run=~run;
		Hz=h*2.0;
		speed=Hz/0.45;
		flow=flow+speed*0.008333;
		if(speed>=Alarm_upper || speed<=Alarm_lower)
			warn=1;
		else
			warn=0;
		h=0;
	}
	if(water==1)
		er=1;
}

void Int0()	interrupt 0		//�ⲿ�ж�0���жϺ���
{
	if(er==1)
	{
		link=~link;
		h++;
		er=0;
	}

}

void UARTInterrupt(void) interrupt 4
{
	char a;
    if(RI)
    {
        RI = 0;
	a=SBUF;
	SBUF=a;
	while(!TI);			 //�ȴ������������
	TI=0;
        //add your code here!
    }
    else
        TI = 0;
}