#include <intrins.h>
void delay500ms(void);
void delay100ms(void);
