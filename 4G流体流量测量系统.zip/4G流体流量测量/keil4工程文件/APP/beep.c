#include<reg52.h>
#include<beep.h>

void delay(int i)
{
	while(i--);	
}

void voice(int x)
{
 	int k;
	for(k=0;k<300;k++)
	{
		beep=~beep;
		delay(x);
	}
}
